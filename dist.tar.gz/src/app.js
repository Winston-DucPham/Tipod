App({
  onLaunch(options) {
    console.log('App onLaunch');
  },
  onShow(options) {
  },
});