const app = getApp();
Page({
  data: {},
  navigateTo(){
    my.navigateTo({url:'pages/play/index'});
  }
});